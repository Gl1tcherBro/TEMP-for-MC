#puts the raw output of the tts into the resourcepacks folder so it does not have to be processed every run
RAW_FOLDER = "../../../raw_voicelines"
OUTPUT_PATH = "sounds/voicelines"

from pedalboard import Pedalboard, Delay, Reverb, Gain
from pedalboard.io import AudioFile
import pyttsx3
import json
import os
import argparse
from pydub import AudioSegment

engine = pyttsx3.init()
voices = engine.getProperty('voices')

print("Available voices:")
for voice in voices:
    print(voice.name)

#load voicelines.json
with open('voicelines.json', 'r') as file:
    dictionary = json.load(file)

#generate raw voicelines
parser = argparse.ArgumentParser()
parser.add_argument('--post', action='store_true', help="Run post effects functions only without generating new raw voicelines.")
args = parser.parse_args()

voicelineCreationCount = 0
if not args.post:
    print(f"\nGenerating raw voicelines...")
    for root, value in dictionary.items():
        os.makedirs(f"{RAW_FOLDER}/{root}", exist_ok=True)
        engine.setProperty('rate', value["talk_speed"])
        for voice in voices:
            if value["type"] in voice.name:
                engine.setProperty('voice', voice.id)
                break

        for file_name, text in value["voicelines"].items():
            delay = 0
            if type(text) != str:
                delay = text["delay"]
                text = text["text"]

            engine.save_to_file(text, f"{RAW_FOLDER}/{root}/{file_name}")
            engine.runAndWait()

            # Apply silence to the end of audio for better reverb and stuff
            audio = AudioSegment.from_file(f"{RAW_FOLDER}/{root}/{file_name}")

            after_delay = AudioSegment.silent(duration=value["after_delay"])
            pre_delay = AudioSegment.silent(duration=delay + value["pre_delay"])

            audio_with_silence = pre_delay + audio + after_delay

            audio_with_silence.export(f"{RAW_FOLDER}/{root}/{file_name}", format="wav")

            voicelineCreationCount += 1

#add post-effects like delay and reverb and assign to sounds.json
sounds = ''
with open('raw_sounds.txt', 'r') as file:
    sounds_json = file.read()

print("Applying post effects...")
#generate raw voicelines
voicelineModificationCount = 0
for root, value in dictionary.items():
    os.makedirs(f"{OUTPUT_PATH}/{root}", exist_ok=True)
    delay_interval = value["delay_interval"]
    delay_feedback = value["delay_feedback"]
    reverb_room_size = value["reverb_room_size"]
    reverb_damping = value["reverb_damping"]
    reverb_width = value["reverb_width"]

    for file_name, text in value["voicelines"].items():
        board = Pedalboard([Gain(gain_db=10), Reverb(width=reverb_damping,damping=reverb_damping,room_size=reverb_room_size), Delay(delay_seconds=delay_interval, feedback=delay_feedback)])

        with AudioFile(f"{RAW_FOLDER}/{root}/{file_name}") as f:
            with AudioFile(f"{OUTPUT_PATH}/{root}/{file_name}", 'w', f.samplerate, f.num_channels) as o:
                
                sounds = sounds + '  "voicelines.'+root+'.'+file_name[:-4]+'":{"sounds":["terf:voicelines/'+root+'/'+file_name[:-4]+'"]},\n'
                # Read one second of audio at a time, until the file is empty:
                while f.tell() < f.frames:
                    chunk = f.read(f.samplerate)
                    
                    # Run the audio through our pedalboard:
                    effected = board(chunk, f.samplerate, reset=False)
                    
                    # Write the output to our output file:
                    o.write(effected)

        voicelineModificationCount += 1

with open('sounds.json', 'w') as file:
    file.write(sounds_json.replace('$(VOICELINES)', sounds))

print(f"\n{voicelineCreationCount} raw voicelines have been created succesfully!\n{voicelineModificationCount} post effects have been added.")